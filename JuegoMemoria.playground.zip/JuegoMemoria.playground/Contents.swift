//: Playground - noun: a place where people can play

import UIKit

for var i = 0; i <= 100; i += 1{
    
    
    if i == 0{
        print(i)
    }
    else{
        var divCinco = i%5
        if divCinco == 0{
            print("\(i) Bingo!!!")
        }
    
        var numPar = i%2
        if numPar == 0{
            print("\(i) par!!!")
        }
        else{
            print("\(i) impar!!!")
        }
    
        if (i >= 30) && (i <= 40){
            print("\(i) Viva Swift!!!")
        }
    }
}
